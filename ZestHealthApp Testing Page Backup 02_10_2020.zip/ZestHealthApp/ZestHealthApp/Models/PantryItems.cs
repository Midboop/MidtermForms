﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ZestHealthApp.Models
{
    public class PantryItems
    {
        public string ItemName { get; set; }
        public string Quantity { get; set; }
        public string Calories { get; set; }
    }
}
