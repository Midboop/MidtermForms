﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Auth;

namespace ZestHealthApp.Services
{
   public class AuthenticationState
    {
        public static OAuth2Authenticator Authenticator;
    }
}
